﻿using AngularWithTokenBasedAuth.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AngularWithTokenBasedAuth.Controllers
{
    public class DepartmentAPIController : ApiController
    {
        static List<DepartmentModel> departmentModels = new List<DepartmentModel>()
        {
            new DepartmentModel()
            {
                PKDeptId=1,DepartmentName="Quality",IsActive=true,
            },
             new DepartmentModel()
            {
                PKDeptId=2,DepartmentName="Finance",IsActive=true,
            },
              new DepartmentModel()
            {
                PKDeptId=3,DepartmentName="IT",IsActive=true,
            }
        };
        // GET api/<controller>
        public IHttpActionResult Get()
        {
            return Ok(departmentModels);
        }

        // GET api/<controller>/5
        public IHttpActionResult Get(int id)
        {
            return Ok(departmentModels.Where(x=>x.PKDeptId==id).SingleOrDefault());
        }

        // POST api/<controller>
        public IHttpActionResult Post(DepartmentModel dept)
        {
            dept.PKDeptId = departmentModels.LastOrDefault().PKDeptId+1;
            departmentModels.Add(dept);
            return Ok(dept);
        }

        // PUT api/<controller>/5
        public IHttpActionResult Put(DepartmentModel newDept)
        {
            var olddeptIndex = departmentModels.IndexOf(departmentModels.Where(x => x.PKDeptId == newDept.PKDeptId).SingleOrDefault());
            departmentModels.RemoveAt(olddeptIndex);
            departmentModels.Insert(olddeptIndex, newDept);
            return Ok(newDept);
        }

        // DELETE api/<controller>/5
        public IHttpActionResult Delete(int id)
        {
            var res = departmentModels.Where(x => x.PKDeptId == id).SingleOrDefault();
            departmentModels.Remove(res);
            return Ok(res);
        }
    }
}