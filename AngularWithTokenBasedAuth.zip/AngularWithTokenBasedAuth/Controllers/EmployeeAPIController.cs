﻿using AngularWithTokenBasedAuth.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AngularWithTokenBasedAuth.Controllers
{
    [Authorize]
    public class EmployeeAPIController : ApiController
    {
        #region PrivateMemeber
        static List<EmployeeModel> employeeModels = new List<EmployeeModel>()
        {
            new EmployeeModel(){EmployeeName="Schott",PKEmployeeId=1,EmployeeSalary=24000,FKDeptId=1},
            new EmployeeModel(){EmployeeName="Sam",PKEmployeeId=2,EmployeeSalary=29000,FKDeptId=3},
            new EmployeeModel(){EmployeeName="San",PKEmployeeId=3,EmployeeSalary=34000,FKDeptId=2}
        };
        #endregion
        #region Constructor
        public EmployeeAPIController()
        {
            var json = GlobalConfiguration.Configuration.Formatters.JsonFormatter;
            json.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
            GlobalConfiguration.Configuration.Formatters.Remove(GlobalConfiguration.Configuration.Formatters.XmlFormatter);
        }
        #endregion
        // GET api/<controller>
        public IHttpActionResult Get()
        {
            return Ok(employeeModels);
        }

        // GET api/<controller>/5
        public IHttpActionResult Get(int id)
        {
            var res = employeeModels.Where(x => x.PKEmployeeId == id).SingleOrDefault();
            return Ok(res);
        }

        // POST api/<controller>
        public IHttpActionResult Post(EmployeeModel employee)
        {
            employee.PKEmployeeId = employeeModels.LastOrDefault().PKEmployeeId + 1;
            employeeModels.Add(employee);
            return Ok(employee);
        }

        // PUT api/<controller>/5
        public IHttpActionResult Put(EmployeeModel newEmployee)
        {
            var oldEmployeeIndex = employeeModels.IndexOf(employeeModels.Where(x => x.PKEmployeeId == newEmployee.PKEmployeeId).SingleOrDefault());
            employeeModels.RemoveAt(oldEmployeeIndex);
            employeeModels.Insert(oldEmployeeIndex, newEmployee);
            return Ok(newEmployee);
        }

        // DELETE api/<controller>/5
        public IHttpActionResult Delete(int id)
        {
            var res = employeeModels.Where(x => x.PKEmployeeId == id).SingleOrDefault();
            employeeModels.Remove(res);
            return Ok(res);
        }
    }
}