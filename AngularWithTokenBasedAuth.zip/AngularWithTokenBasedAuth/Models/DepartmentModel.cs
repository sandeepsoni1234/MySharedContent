﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AngularWithTokenBasedAuth.Models
{
    public class DepartmentModel
    {
        public int PKDeptId { get; set; }
        public string DepartmentName { get; set; }
        public bool IsActive { get; set; }
    }
}