﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AngularWithTokenBasedAuth.Models
{
    public class EmployeeModel
    {
        public int PKEmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public decimal EmployeeSalary { get; set; }
        public int FKDeptId { get; set; }
    }
}