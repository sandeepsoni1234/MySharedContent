"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var Login_component_1 = require("./Components/Login.component");
var Employee_component_1 = require("./Components/Employee.component");
var Department_component_1 = require("./Components/Department.component");
var AuthGuard_1 = require("./Auth/AuthGuard");
var routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: Login_component_1.LoginComponent },
    { path: 'employee', component: Employee_component_1.EmployeeComponent, canActivate: [AuthGuard_1.AuthGuard] },
    { path: 'department', component: Department_component_1.DepartmentComponent, canActivate: [AuthGuard_1.AuthGuard] }
];
exports.routing = router_1.RouterModule.forRoot(routes);
//# sourceMappingURL=app.routing.js.map