"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var EmployeeModel_1 = require("./../Model/EmployeeModel");
var EmployeeService_1 = require("./../Services/EmployeeService");
var AuthKeyGen_1 = require("./../Auth/AuthKeyGen");
var DepartmentService_1 = require("./../Services/DepartmentService");
var EmployeeComponent = /** @class */ (function () {
    function EmployeeComponent(empService, deptService, router, authkKeyGen) {
        this.empService = empService;
        this.deptService = deptService;
        this.router = router;
        this.authkKeyGen = authkKeyGen;
        this.Employees = [];
        this.Emp = new EmployeeModel_1.EmployeeModel();
        this.Depts = [];
        this.GetAll();
        this.GetDepartments();
    }
    EmployeeComponent.prototype.GetAll = function () {
        var _this = this;
        this.empService.GetAll().subscribe(function (data) {
            _this.Employees = data;
        });
    };
    EmployeeComponent.prototype.GetDepartments = function () {
        var _this = this;
        this.deptService.GetAll().subscribe(function (data) {
            _this.Depts = data;
        });
    };
    EmployeeComponent.prototype.Get = function (id) {
        this.Emp = this.Employees.filter(function (x) { return x.PKEmployeeId == id; })[0];
    };
    EmployeeComponent.prototype.Add = function () {
        this.Emp = new EmployeeModel_1.EmployeeModel();
        this.Emp.PKEmployeeId = 0;
    };
    EmployeeComponent.prototype.Save = function () {
        var _this = this;
        if (this.Emp.PKEmployeeId == 0) {
            this.empService.Add(this.Emp).subscribe(function () {
                _this.GetAll();
            });
        }
        else {
            this.empService.Edit(this.Emp).subscribe(function () {
                _this.GetAll();
            });
        }
    };
    EmployeeComponent.prototype.Delete = function () {
        var _this = this;
        this.empService.Delete(this.Emp.PKEmployeeId).subscribe(function () {
            _this.GetAll();
        });
    };
    EmployeeComponent = __decorate([
        core_1.Component({
            templateUrl: './../Views/employee.html',
            selector: "employee",
            providers: [EmployeeService_1.EmployeeService, DepartmentService_1.DepartmentService]
        }),
        __metadata("design:paramtypes", [EmployeeService_1.EmployeeService, DepartmentService_1.DepartmentService, router_1.Router, AuthKeyGen_1.AuthKeyGen])
    ], EmployeeComponent);
    return EmployeeComponent;
}());
exports.EmployeeComponent = EmployeeComponent;
//# sourceMappingURL=Employee.component.js.map