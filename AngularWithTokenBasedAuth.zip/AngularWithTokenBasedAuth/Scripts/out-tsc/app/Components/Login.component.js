"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var UserServices_1 = require("./../Services/UserServices");
var AuthKeyGen_1 = require("./../Auth/AuthKeyGen");
var LoginComponent = /** @class */ (function () {
    function LoginComponent(userService, router, authKeyGen) {
        this.userService = userService;
        this.router = router;
        this.authKeyGen = authKeyGen;
        //for onrefresh
        if (localStorage.getItem('AccessToken') != null) {
            this.router.navigate(['./employee']);
        }
    }
    LoginComponent.prototype.LoginClick = function () {
        var _this = this;
        this.errormessage = "";
        if (this.emailAddress == "" || this.emailAddress == null || this.emailAddress == undefined) {
            this.errormessage = "User name is required";
            return;
        }
        if (this.password == "" || this.password == null || this.password == undefined) {
            this.errormessage = "Password is required";
            return;
        }
        this.isLoading = true;
        this.userService.Authenticate(this.emailAddress, this.password).subscribe(function (token) {
            _this.isLoading = false;
            if (token != null) {
                localStorage.setItem("AccessToken", JSON.stringify(token));
                _this.authKeyGen.RefereshToken();
                _this.router.navigate(['./employee']);
            }
            else {
                _this.errormessage = "Please provide valid username and password";
            }
        });
    };
    LoginComponent = __decorate([
        core_1.Component({
            templateUrl: './../Views/login.html',
            selector: "login"
        }),
        __metadata("design:paramtypes", [UserServices_1.UserService, router_1.Router, AuthKeyGen_1.AuthKeyGen])
    ], LoginComponent);
    return LoginComponent;
}());
exports.LoginComponent = LoginComponent;
//Access Token Object returned from server.
//{
//    "access_token": "yMdwj8j_Ww8Ze_kx2QQZHdpcns5IinsMgS9WUSMzjBmNwXw",
//    "token_type": "bearer",
//    "expires_in": 1799,
//    "userName": "Admin",
//    ".issued": "Wed, 08 Aug 2018 09:57:20 GMT",
//    ".expires": "Wed, 08 Aug 2018 10:27:20 GMT"
//}
//# sourceMappingURL=Login.component.js.map