"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var DepartmentModel_1 = require("./../Model/DepartmentModel");
var DepartmentService_1 = require("./../Services/DepartmentService");
var DepartmentComponent = /** @class */ (function () {
    function DepartmentComponent(deptService, router) {
        this.deptService = deptService;
        this.router = router;
        this.Depts = [];
        this.Dept = new DepartmentModel_1.DepartmentModel();
        this.GetAll();
    }
    DepartmentComponent.prototype.GetAll = function () {
        var _this = this;
        this.deptService.GetAll().subscribe(function (data) {
            _this.Depts = data;
        });
    };
    DepartmentComponent.prototype.Get = function (id) {
        this.Dept = this.Depts.filter(function (x) { return x.PKDeptId == id; })[0];
    };
    DepartmentComponent.prototype.Add = function () {
        this.Dept = new DepartmentModel_1.DepartmentModel();
        this.Dept.PKDeptId = 0;
    };
    DepartmentComponent.prototype.Save = function () {
        var _this = this;
        if (this.Dept.PKDeptId == 0) {
            this.deptService.Add(this.Dept).subscribe(function () {
                _this.GetAll();
            });
        }
        else {
            this.deptService.Edit(this.Dept).subscribe(function () {
                _this.GetAll();
            });
        }
    };
    DepartmentComponent.prototype.Delete = function () {
        var _this = this;
        this.deptService.Delete(this.Dept.PKDeptId).subscribe(function () {
            _this.GetAll();
        });
    };
    DepartmentComponent = __decorate([
        core_1.Component({
            templateUrl: './../Views/department.html',
            selector: "dept",
            providers: [DepartmentService_1.DepartmentService]
        }),
        __metadata("design:paramtypes", [DepartmentService_1.DepartmentService, router_1.Router])
    ], DepartmentComponent);
    return DepartmentComponent;
}());
exports.DepartmentComponent = DepartmentComponent;
//# sourceMappingURL=Department.component.js.map