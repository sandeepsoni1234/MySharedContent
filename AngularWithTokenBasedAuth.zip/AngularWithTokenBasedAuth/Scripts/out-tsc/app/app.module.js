"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var platform_browser_1 = require("@angular/platform-browser");
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var app_component_1 = require("./app.component");
var Login_component_1 = require("./Components/Login.component");
var app_routing_1 = require("./app.routing");
var http_1 = require("@angular/common/http");
var Employee_component_1 = require("./Components/Employee.component");
var Department_component_1 = require("./Components/Department.component");
var AuthInterceptor_1 = require("./Auth/AuthInterceptor");
var AuthGuard_1 = require("./Auth/AuthGuard");
var AuthKeyGen_1 = require("./Auth/AuthKeyGen");
var UserServices_1 = require("./Services/UserServices");
var common_1 = require("@angular/common");
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            declarations: [
                app_component_1.AppComponent, Login_component_1.LoginComponent, Employee_component_1.EmployeeComponent, Department_component_1.DepartmentComponent
            ],
            imports: [
                platform_browser_1.BrowserModule, app_routing_1.routing, forms_1.FormsModule, http_1.HttpClientModule
            ],
            providers: [
                {
                    provide: http_1.HTTP_INTERCEPTORS,
                    useClass: AuthInterceptor_1.AuthInterceptor,
                    multi: true
                },
                AuthGuard_1.AuthGuard, AuthKeyGen_1.AuthKeyGen, UserServices_1.UserService,
                { provide: common_1.LocationStrategy, useClass: common_1.HashLocationStrategy }
            ],
            bootstrap: [app_component_1.AppComponent]
        })
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map