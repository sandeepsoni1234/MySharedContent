"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var UserServices_1 = require("./../Services/UserServices");
var rxjs_1 = require("rxjs");
var AuthKeyGen = /** @class */ (function () {
    function AuthKeyGen(userService) {
        this.userService = userService;
    }
    AuthKeyGen.prototype.RefereshToken = function () {
        var _this = this;
        this.isLogin = true;
        var t = rxjs_1.timer(25 * 1000, 25 * 1000); //25 Seconds
        this.subscription = t.subscribe(function (t) {
            var data = JSON.parse(localStorage.getItem('AccessToken'));
            //Following code will not work if authentication logic is changed.
            //Call here an API method to get new token for an existing token...
            _this.userService.Authenticate(data.userName, data.userName).subscribe(function (data) {
                if (data != null) {
                    localStorage.setItem("AccessToken", JSON.stringify(data));
                }
            });
        });
    };
    AuthKeyGen.prototype.Clear = function () {
        this.isLogin = false;
        //To stop or cancel the ongoing execution of subscribed method.
        this.subscription.unsubscribe();
    };
    AuthKeyGen.prototype.diff_secs = function (dt2, dt1) {
    };
    AuthKeyGen = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [UserServices_1.UserService])
    ], AuthKeyGen);
    return AuthKeyGen;
}());
exports.AuthKeyGen = AuthKeyGen;
//# sourceMappingURL=AuthKeyGen.js.map