"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DepartmentModel = /** @class */ (function () {
    function DepartmentModel() {
    }
    return DepartmentModel;
}());
exports.DepartmentModel = DepartmentModel;
//# sourceMappingURL=DepartmentModel.js.map