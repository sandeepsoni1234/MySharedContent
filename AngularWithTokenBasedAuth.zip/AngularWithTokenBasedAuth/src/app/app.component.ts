import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthKeyGen } from "./Auth/AuthKeyGen";
import { debug } from 'util';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
    styleUrls: ['./app.component.css'],
})
export class AppComponent {
    title = 'My First Angular App!';
    constructor(public authkKeyGen: AuthKeyGen, private router: Router) {
        if (localStorage.getItem('AccessToken') != null) {
            this.authkKeyGen.isLogin = true;
            this.authkKeyGen.RefereshToken();
        }
    }

    Logout() {
        localStorage.removeItem('AccessToken');
        this.router.navigate(['./login']);
        this.authkKeyGen.Clear();
    }
}
