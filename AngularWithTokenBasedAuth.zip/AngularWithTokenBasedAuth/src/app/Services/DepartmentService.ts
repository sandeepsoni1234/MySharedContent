﻿import { DepartmentModel } from "./../Model/DepartmentModel";
import { Injectable } from '@angular/core';
import { map, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';
import {
    HttpClient,
    HttpParams,
    HttpErrorResponse, HttpHeaders
} from '@angular/common/http';
const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

@Injectable()
export class DepartmentService {
    url: string = "/api/DepartmentAPI";
    constructor(protected http: HttpClient) {
    }

    GetAll(): Observable<DepartmentModel[]> {
        return this.http.get<DepartmentModel[]>(this.url).pipe(map(data => data));
    }

    Add(employeeModel: DepartmentModel): Observable<DepartmentModel> {
        let data = JSON.stringify(employeeModel);
        return this.http.post<DepartmentModel>(this.url, data, httpOptions).pipe(map(data => data));
    }

    Edit(employeeModel: DepartmentModel): Observable<DepartmentModel> {
        let data = JSON.stringify(employeeModel);
        return this.http.put<DepartmentModel>(this.url, data, httpOptions).pipe(map(data => data));
    }

    Delete(id: any): Observable<DepartmentModel> {
        return this.http.delete<DepartmentModel>(this.url + "/" + id).pipe(map(data => data));
    }
}