﻿import { EmployeeModel } from "./../Model/EmployeeModel";
import { Injectable } from '@angular/core';
import { map, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';
import {
    HttpClient,
    HttpParams,
    HttpErrorResponse, HttpHeaders
} from '@angular/common/http';
const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

@Injectable()
export class EmployeeService {
    url: string = "/api/EmployeeAPI";
    constructor(protected http: HttpClient) {
    }

    GetAll():
        Observable<EmployeeModel[]> {
        return this.http.get<EmployeeModel[]>(this.url).pipe(map(data => data));
    }

    Add(employeeModel: EmployeeModel): Observable<EmployeeModel> {
        let data = JSON.stringify(employeeModel);
        return this.http.post<EmployeeModel>(this.url, data, httpOptions).pipe(map(data => data));
    }

    Edit(employeeModel: EmployeeModel): Observable<EmployeeModel> {
        let data = JSON.stringify(employeeModel);
        return this.http.put<EmployeeModel>(this.url, data, httpOptions).pipe(map(data => data));
    }

    Delete(id: any): Observable<EmployeeModel> {
        return this.http.delete<EmployeeModel>(this.url+"/"+id).pipe(map(data => data));
    }
}