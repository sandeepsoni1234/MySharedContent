﻿import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable()
export class UserService {
    tokenurl: string = "/Token";
    constructor(protected http: HttpClient) {
    }

    Authenticate(userName: string, password: string): Observable<any> {
        var data = "username=" + userName + "&password=" + password + "&grant_type=password";
        var reqHeader = new HttpHeaders({ 'Content-Type': 'application/x-www-urlencoded', 'No-Auth': 'True' });
        return this.http.post<any>(this.tokenurl, data, { headers: reqHeader });
    }

}