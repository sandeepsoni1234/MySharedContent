﻿import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from "./Components/Login.component";
import { EmployeeComponent } from './Components/Employee.component';
import { DepartmentComponent } from './Components/Department.component';
import { AuthGuard } from "./Auth/AuthGuard";
const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    {path: 'employee', component: EmployeeComponent, canActivate: [AuthGuard]},
    {path: 'department', component: DepartmentComponent, canActivate: [AuthGuard]}
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
