﻿export class EmployeeModel {
    public PKEmployeeId: number;
    public EmployeeName: string;
    public EmployeeSalary: number;
    public FKDeptId: number;
}