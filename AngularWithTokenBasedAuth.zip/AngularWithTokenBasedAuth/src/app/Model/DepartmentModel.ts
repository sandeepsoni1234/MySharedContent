﻿export class DepartmentModel {
    public PKDeptId: number;
    public DepartmentName: string;
    public IsActive: boolean;
}