﻿import { Injectable } from '@angular/core';
import { UserService } from './../Services/UserServices';
import { timer, Observable, Subscription } from 'rxjs';

@Injectable()
export class AuthKeyGen {
    subscription: Subscription;
    isLogin: boolean;
    constructor(private userService: UserService) { }

    RefereshToken() {
        this.isLogin = true;
        var t: Observable<number> = timer(25 * 1000, 25 * 1000); //25 Seconds
        this.subscription = t.subscribe(t => {
            var data = JSON.parse(localStorage.getItem('AccessToken'));
            //Following code will not work if authentication logic is changed.
            //Call here an API method to get new token for an existing token...
            this.userService.Authenticate(data.userName, data.userName).subscribe((data) => {
                if (data != null) {
                    localStorage.setItem("AccessToken", JSON.stringify(data));
                }
            });
        });
    }


    Clear() {
        this.isLogin = false;
        //To stop or cancel the ongoing execution of subscribed method.
        this.subscription.unsubscribe();
    }


    diff_secs(dt2, dt1) {

    }
}
