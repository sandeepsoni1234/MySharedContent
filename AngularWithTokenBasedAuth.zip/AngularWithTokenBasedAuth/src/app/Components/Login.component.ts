﻿import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from "./../Services/UserServices";
import { AuthKeyGen } from "./../Auth/AuthKeyGen";
import { debug } from 'util';

@Component({
    templateUrl: './../Views/login.html',
    selector: "login"
})
export class LoginComponent {
    errormessage: string;
    emailAddress: string;
    password: string;
    isLoading: boolean;
    constructor(private userService: UserService, private router: Router, private authKeyGen: AuthKeyGen) {
        //for onrefresh
        if (localStorage.getItem('AccessToken') != null) {
            this.router.navigate(['./employee']);
        }
    }


    LoginClick() {
        this.errormessage = "";

        if (this.emailAddress == "" || this.emailAddress == null || this.emailAddress == undefined) {
            this.errormessage = "User name is required";
            return;
        }
        if (this.password == "" || this.password == null || this.password == undefined) {
            this.errormessage = "Password is required";
            return;
        }
        this.isLoading = true;
        this.userService.Authenticate(this.emailAddress, this.password).subscribe((token) => {
            this.isLoading = false;
            if (token != null) {
                localStorage.setItem("AccessToken", JSON.stringify(token));
                this.authKeyGen.RefereshToken();
                this.router.navigate(['./employee']);
            }
            else {
                this.errormessage = "Please provide valid username and password";
            }
        })

    }
}

//Access Token Object returned from server.
//{
//    "access_token": "yMdwj8j_Ww8Ze_kx2QQZHdpcns5IinsMgS9WUSMzjBmNwXw",
//    "token_type": "bearer",
//    "expires_in": 1799,
//    "userName": "Admin",
//    ".issued": "Wed, 08 Aug 2018 09:57:20 GMT",
//    ".expires": "Wed, 08 Aug 2018 10:27:20 GMT"
//}