﻿import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DepartmentModel } from './../Model/DepartmentModel';
import { DepartmentService } from './../Services/DepartmentService';

@Component({
    templateUrl: './../Views/department.html',
    selector: "dept",
    providers: [DepartmentService]
})
export class DepartmentComponent {
    Depts: DepartmentModel[] = [];
    Dept: DepartmentModel = new DepartmentModel();

    constructor(private deptService: DepartmentService, private router: Router) {
        this.GetAll();
    }

    GetAll() {
        this.deptService.GetAll().subscribe((data) => {
            this.Depts = data;
        });
    }
    Get(id: any) {
        this.Dept = this.Depts.filter((x) => x.PKDeptId == id)[0];
    }

    Add() {
        this.Dept = new DepartmentModel();
        this.Dept.PKDeptId = 0;
    }

    Save() {
        if (this.Dept.PKDeptId == 0) {
            this.deptService.Add(this.Dept).subscribe(() => {
                this.GetAll();
            });
        }
        else {
            this.deptService.Edit(this.Dept).subscribe(() => {
                this.GetAll();
            });
        }

    }
    Delete() {
        this.deptService.Delete(this.Dept.PKDeptId).subscribe(() => {
            this.GetAll();
        });
    }

}

