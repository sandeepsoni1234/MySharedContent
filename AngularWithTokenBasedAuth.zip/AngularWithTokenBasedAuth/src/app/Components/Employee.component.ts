﻿import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeModel } from './../Model/EmployeeModel';
import { EmployeeService } from './../Services/EmployeeService';
import { AuthKeyGen } from './../Auth/AuthKeyGen';
import { DepartmentModel } from './../Model/DepartmentModel';
import { DepartmentService } from './../Services/DepartmentService';


@Component({
    templateUrl: './../Views/employee.html',
    selector: "employee",
    providers: [EmployeeService, DepartmentService]
})
export class EmployeeComponent {
    Employees: EmployeeModel[] = [];
    Emp: EmployeeModel = new EmployeeModel();
    Depts: DepartmentModel[] = [];
    constructor(private empService: EmployeeService, private deptService: DepartmentService, private router: Router, private authkKeyGen: AuthKeyGen) {
        this.GetAll();
        this.GetDepartments();
    }

    GetAll() {
        this.empService.GetAll().subscribe((data) => {
            this.Employees = data;
        });
    }

    GetDepartments() {
        this.deptService.GetAll().subscribe((data) => {
            this.Depts = data;
        });
    }

    Get(id: any) {
        this.Emp = this.Employees.filter((x) => x.PKEmployeeId == id)[0];
    }

    Add() {
        this.Emp = new EmployeeModel();
        this.Emp.PKEmployeeId = 0;
    }

    Save() {
        if (this.Emp.PKEmployeeId == 0) {
            this.empService.Add(this.Emp).subscribe(() => {
                this.GetAll();
            });
        }
        else {
            this.empService.Edit(this.Emp).subscribe(() => {
                this.GetAll();
            });
        }
    }

    Delete() {
        this.empService.Delete(this.Emp.PKEmployeeId).subscribe(() => {
            this.GetAll();
        });
    }


   
}