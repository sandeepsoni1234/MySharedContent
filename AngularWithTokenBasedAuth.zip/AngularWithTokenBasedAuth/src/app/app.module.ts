import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './Components/Login.component';
import { routing } from "./app.routing";
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { EmployeeComponent } from "./Components/Employee.component";
import { DepartmentComponent } from "./Components/Department.component";
import { AuthInterceptor } from "./Auth/AuthInterceptor";
import { AuthGuard } from "./Auth/AuthGuard";
import { AuthKeyGen } from "./Auth/AuthKeyGen";
import { UserService } from "./Services/UserServices";
import { LocationStrategy, HashLocationStrategy, PathLocationStrategy } from '@angular/common';

@NgModule({
    declarations: [
        AppComponent, LoginComponent, EmployeeComponent, DepartmentComponent
    ],
    imports: [
        BrowserModule, routing, FormsModule, HttpClientModule
    ],
    providers: [
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthInterceptor,
            multi: true
        },
        AuthGuard, AuthKeyGen, UserService,
        { provide: LocationStrategy, useClass: HashLocationStrategy } //Required to injext "#" in URL

    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
