import { Component} from '@angular/core';
import { Department } from './department'

@Component({
    templateUrl:'./department.component.html'
})
export class DepartmentComponent{
    depts: Department[];
        constructor() {
        var lstDept: Department[] = [
            { DeptId: 1, DeptName: "D1" },
            { DeptId: 2, DeptName: "D2" }
        ];
        this.depts = lstDept;
    }
}
