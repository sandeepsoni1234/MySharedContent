export class Department {
    DeptId: number;
    DeptName: string;
}
