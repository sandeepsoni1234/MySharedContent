import { NgModule } from '@angular/core';
import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { DepartmentComponent } from './department/department.component';
import { FileNotFoundComponent } from './file-not-found/file-not-found.component'
import { HomeComponent } from './home/home.component'

const routes: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },

    { path:'**', component: FileNotFoundComponent}
];
let routing = RouterModule.forRoot(routes, { enableTracing: true })

@NgModule({
    imports: [
        routing
 	//enable Tracing is for debugging purposes only
    ],
    exports: [
        RouterModule
    ]
})
export class AppRoutingModule { }
