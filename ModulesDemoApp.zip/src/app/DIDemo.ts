import {Inject, Injectable } from "@angular/core"

@Injectable()
export class Independent
{
    sayHello(): string
    {
        return("hello")
    }
}

@Injectable()
export class Dependent
{
    message: string
    //ind: Independent;
    constructor(private ind: Independent)
    { 
        this.ind = ind
    }
    someMethod(): string
    {
        return this.ind.sayHello();
    }
}