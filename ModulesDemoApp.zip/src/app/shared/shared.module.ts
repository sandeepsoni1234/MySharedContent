import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgePipe } from './AgePipe';

@NgModule({
  imports: [CommonModule],
  declarations: [AgePipe],
  exports: [AgePipe,CommonModule]
})
export class SharedModule { }
