import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'age' })
export class AgePipe implements PipeTransform {
    transform(date: Date, format:string): string {
        let todayOffset = new Date().getTime();
        let pardateTimeOffset = date.getTime();
        let diff = todayOffset - pardateTimeOffset;
        let oneDay = 1000 * 60 * 60 * 24
        if (format == null || format.toLowerCase() == "y")
            return Math.floor(diff / (oneDay * 365)) + " Years";
        else if (format.toLowerCase() == "m")
            return Math.floor(diff / (oneDay * 31)) + " Months";
        else if (format.toLowerCase() == "d")
            return Math.floor(diff / (oneDay)) + " Days"
    }

}

@Pipe({
    name: "join",
    pure: false
})
export class JoinPipe implements PipeTransform {
    transform(value: any) : string {
        return value.join(",");
    }
}
