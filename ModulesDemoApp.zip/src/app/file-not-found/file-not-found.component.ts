import { Component } from '@angular/core';
@Component({
    template: `Request File/URL is not found`
})
export class FileNotFoundComponent {
}
