import { Department } from '../department/department'
export class Employee {
    EmpId: number;
    EmpName: string;
    EmpSalary: number;
    Department: Department;
}
