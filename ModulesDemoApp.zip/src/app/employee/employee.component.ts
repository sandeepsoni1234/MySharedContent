import { Component } from '@angular/core';
import { Employee } from './employee';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  templateUrl: './Employee.component.html'
})
export class EmployeeComponent {
  dateDemo:Date = new Date()
  emps: Employee[];
  selectedEmployee: Employee = null;
  constructor(private route: ActivatedRoute) {
    var lstEmp: Employee[] = [
      { EmpId: 1, EmpName: "Phani", EmpSalary: 15000, Department: { DeptId: 1, DeptName: "D1" } },
      { EmpId: 2, EmpName: "Kranth", EmpSalary: 115000, Department: { DeptId: 2, DeptName: "D2" } }
    ];
    this.emps = lstEmp;
  }

  paramsSub: any;
  dataSub: any;
  pageTitle: string = ""
  obj: any = null;
  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    //The route.snapshot provides the initial value of the route parameter map.

    this.selectedEmployee = this.emps.filter(e => e.EmpId.toString() == id)[0];

    //Deprecated Code   
    //this.paramsSub = this.route.params.subscribe(params => {
    //  if (params["id"] != null)
    //          this.selectedEmployee = this.emps.filter(e => e.EmpId == params["id"])[0];
    //  });

    this.paramsSub = this.route.paramMap.subscribe(
      paramMap => {
        this.obj = paramMap
        this.selectedEmployee = this.emps.filter(e => e.EmpId == +paramMap.get("id"))[0];
      }
    )
    this.dataSub = this.route.data.subscribe(data => {
      this.pageTitle = data["title"];
    })
  }
  ngOnDestroy() {
    this.paramsSub.unsubscribe();
    this.dataSub.unsubscribe();
  }

}
