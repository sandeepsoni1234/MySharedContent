import { Component } from '@angular/core';
@Component({
  template: `
 	<div class="well">
    	<h1>Welcome (this is home)</h1>
  </div>
  <div>
      <router-outlet></router-outlet>
  </div>
`
})
export class HomeComponent {
}
