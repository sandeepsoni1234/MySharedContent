import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { FileNotFoundComponent } from './file-not-found/file-not-found.component';
import { AppRoutingModule } from './app.routing';
import { EmployeeModule } from './employee/employee.module';
import { DepartmentModule } from './department/department.module';


@NgModule({
  declarations: [
    AppComponent, HomeComponent, FileNotFoundComponent
  ],
  imports: [
    BrowserModule, FormsModule, EmployeeModule, DepartmentModule, AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
